# TradingView Indicator

- Based on [https://github.com/reg2005/tradingview-ta-docker](https://github.com/reg2005/tradingview-ta-docker)
- Based on [https://github.com/brian-the-dev/python-tradingview-ta](https://github.com/brian-the-dev/python-tradingview-ta)

Since `tradingview-ta-docker` does not provide ARM docker image, I had to build in this project.
