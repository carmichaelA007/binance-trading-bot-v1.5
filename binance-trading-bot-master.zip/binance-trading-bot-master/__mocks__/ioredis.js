const ioredis = jest.createMockFromModule('ioredis');

module.exports = ioredis;
